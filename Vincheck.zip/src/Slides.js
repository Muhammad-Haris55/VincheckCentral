// // alert('helo')
// let slideIndex = 0;
// const slides = document.querySelectorAll('.slide');

// function showSlide(index) {
//   if (index < 0) {
//     slideIndex = slides.length - 1;
//   } else if (index >= slides.length) {
//     slideIndex = 0;
//   } else {
//     slideIndex = index;
//   }

//   const offset = -slideIndex * (100 / 3);
//   document.querySelector('.slide-track').style.transform = `translateX(${offset}%)`;
// }

// function prevSlide() {
//   showSlide(slideIndex - 1);
// }

// function nextSlide() {
//   showSlide(slideIndex + 1);
// }

// showSlide(slideIndex);
